package com.vocab2000fa.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()